This software is provided "as-is". I am not responsible for any damage caused by this software.

# Program


You may modify and redistribute this software only if you follow the guidelines below. You must also follow these rules when distributing a modified version of this software.
1. You do not sell it.
2. You do not claim it as your own work.
3. You provide a link to the original Github repository (https://github.com/misterpug51/sticky).
4. You provide a link to the original Github repository (https://github.com/misterpug51/sticky) within the software if you modify it.
