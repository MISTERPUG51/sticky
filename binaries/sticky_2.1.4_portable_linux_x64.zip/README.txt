Instructions:

1. Mark the "sticky.x86_64" file as executable.
   You can do this by running the following command in this directory:
   chmod +x sticky.x86_64

2. You can launch the game by running the following command"
   ./sticky.x86_64