By running this software, you are agreeing to the license agreement for the software. This license agreement can be found at: https://github.com/MISTERPUG51/sticky/blob/main/license.md

If you download an update through the game's built-in updater, the program will install to your system. The updater will NOT modify any files in the portable version.